using System;
using System.Text;
using System.Windows.Forms;

namespace MultiplicationTable
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string inputValue = textBox1.Text;
            int number;
            if (int.TryParse(inputValue, out number))
            {
                if (number >= 1 && number <= 10)
                {
                    StringBuilder sb = new StringBuilder();
                    for (int i = 1; i <= 10; i++)
                    {
                        sb.AppendLine($"{i} * {number} = {i * number}");
                    }
                    MessageBox.Show(sb.ToString(), "Multiplication Table", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Please enter an integer between 1 and 10.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid integer number.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
